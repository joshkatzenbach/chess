package services;

import dao.AuthDao;
import dataAccess.DataAccessException;
import results.LogoutResult;
import requests.*;

public class LogoutService {
    public LogoutResult logout(String authToken) {

        if (!new AuthDao().authorizeToken(authToken)) {
            LogoutResult result = new LogoutResult();
            result.setErrorCode(401);
            result.setMessage("Error: Unauthorized");
            return result;
        }

        try {
            new AuthDao().removeToken(authToken);
            LogoutResult result = new LogoutResult();
            result.setErrorCode(200);
            return result;
        }
        catch (DataAccessException ex) {
            LogoutResult errorResult = new LogoutResult();
            errorResult.setErrorCode(500);
            errorResult.setMessage(ex.getMessage());
            return errorResult;
        }
    }
}
